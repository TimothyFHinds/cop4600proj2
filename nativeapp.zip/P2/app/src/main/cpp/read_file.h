#ifndef READ_FILE
#define READ_FILE

char *read_file(const char *filename);

#endif

